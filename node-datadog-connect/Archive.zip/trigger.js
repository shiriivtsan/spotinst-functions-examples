const rp = require('request-promise')

module.exports.main = function main (event, context, callback) {
	// Data dog key
	let key = "a842b6b80f1bc3e4be42511e49fb39ca"

	let title = ""
	let text = ""

	// Check if event has been triggered
	try{
	    let eventDetails = JSON.parse(JSON.parse(event.body).message)
	    console.log(eventDetails)

	    // check the event type to send to DD
		if(eventDetails.event == "AWS_EC2_INSTANCE_LAUNCH"){
			title = "New Instance Launched in " + eventDetails.resourceId
			text = "Instance ID " + eventDetails.instanceId
		}else if(eventDetails.event == "AWS_EC2_INSTANCE_TERMINATE"){
			title = "Instance Terminated in " + eventDetails.resourceId
			text = "Instance ID " + eventDetails.instanceId
		}else if(eventDetails.event == "AWS_EC2_INSTANCE_UNHEALTHY_IN_ELB"){
			title = "Instance Unhealthy in " + eventDetails.resourceId
			text = "Instance ID " + eventDetails.instanceId
		}
	}catch(e){
		console.log(e)
	    callback(null, {
			statusCode: 400, 
			body: 'Error: Check logs',
			headers: {"Content-Type": "application/json"}
		});
	}

	// Options to post an event to DD
	let options = {
		uri:'https://app.datadoghq.com/api/v1/events',
		method: "POST",
		qs: {api_key: key},
		headers: {
			"Content-Type": "application/json"},
		body: 
		{"title": title,
		"text": text,
		"priority": "normal",
		"tags": ["Spotinst"],
		"alert_type": "info"},
		json:true
	}

	console.log(title)
	rp(options).then((res)=>{
		console.log(res)
	    callback(null, {
			statusCode: 200, 
			body: 'Success',
			headers: {"Content-Type": "application/json"}
		});
	}).catch((err)=>{
		console.log(err)
	    callback(null, {
			statusCode: 400, 
			body: 'Error: Check logs',
			headers: {"Content-Type": "application/json"}
		});
	})
};
